/* mylist.h declares functions that extend the STL list.
 *
 * Begun by: Dr. Jump, CS 315 at King's College
 * Completed by:
 * Date:
 */

#include <list>           // list<>
using namespace std;


