/* Duck.h
 *
 * Begun by: Dr. Jump for CS 315 at King's College
 * Completed by:
 * Date:
 */

#ifndef DUCK
#define DUCK

#include "Bird.h"

class Duck {
 public:

 private:

};

// insert method definitions here

#endif
