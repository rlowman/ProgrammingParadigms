/* Goose.h
 * Begun by: Dr. Jump for CS 315 at King's College
 * Completed by:
 * Date:
 */

#ifndef GOOSE
#define GOOSE

#include "Bird.h"

class Goose : public Bird {
 public:

 private:

};

// insert method definitions here

#endif
