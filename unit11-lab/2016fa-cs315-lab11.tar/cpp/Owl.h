/* Owl.h
 *
 * Begun by: Dr. Jump for CS 315 at King's College
 * Completed by:
 * Date:
 */

#ifndef OWL
#define OWL

#include "Bird.h"

class Owl {
 public:

 private:

};

// insert method defintions here

#endif
