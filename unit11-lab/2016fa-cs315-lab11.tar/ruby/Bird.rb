# Bird.rb | Defines a Bird superclass to be extended by specific bird
#   sub-classes.
#
# Begun by: Dr. Jump, for CS 315 at King's College.
# Completed by:
# Date:
####################################################

class Bird


end
