# Owl.rb | Defines the Owl class which inherits attributes and methods
#   from the Bird superclass.
#
# Begun by: Dr. Jump for CS 315 at King's College.
# Completed by:
# Date:
####################################################

require_relative 'Bird.rb'

class Owl

end
